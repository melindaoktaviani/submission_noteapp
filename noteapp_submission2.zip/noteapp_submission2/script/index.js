import "./app.js";
import "./footer.js";
import "./header.js";
import "./item.js";
import "../css/styles.css";

document.addEventListener("DOMContentLoaded", () => {
  fetchNotes();
});
